Rstackdeque
========================================================

Persistent stacks, deques, and queues for R
---------------------------------------------


More info to come as this package is reviewed.

Install
---------

You can install this package via devtools:

```
> install.packages("devtools")  # if needed
> devtools::install_github("oneilsh/rstackdeque")
```

Then load it up and check the help:

```
> require(rstackdeque)
> help(rstackdeque)
> help(rstack)
> help(rdeque)
> help(rpqueue)
```
