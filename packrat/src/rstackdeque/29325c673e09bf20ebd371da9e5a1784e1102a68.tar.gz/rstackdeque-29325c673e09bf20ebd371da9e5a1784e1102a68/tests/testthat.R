library(testthat)
library(rstackdeque)

test_check("rstackdeque")
